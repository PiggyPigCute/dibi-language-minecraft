# dibi-language-minecraft
Language ressource pack to translate minecraft for dibi
