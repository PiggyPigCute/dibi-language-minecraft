
Voici ce qui reste à traduire pour l'instant :

* de la ligne **10** à la ligne **43** (`narration` and `chat screen`)
* de la ligne **212** à la ligne **898** (game options)
* de la ligne **2762** à la fin
* tous les mots entre \[crochets]


Voici ce qui a été traduit pour l'instant :

* de la ligne **5** à la ligne **10** (`narration`)
* de la ligne **44** à la ligne **211** (`gui`, `tranlation.test`, `menu`, `optimizeWorld`, `selectWorld` and `createWorld`)
* de la ligne **899** à la ligne **2761** (`block`, `item`, `instrument`, `container`, `structure_block`, `jigsaw_block`, `filled_map`, `entity`, `death`, `potion` `enchatement`)

